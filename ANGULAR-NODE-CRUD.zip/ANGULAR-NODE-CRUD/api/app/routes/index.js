/**
 |----------------------------------
 | Api Route
 |----------------------------------
 */

 const express = require("express")
 const router = express.Router()
 const UserRouter = require('./user.route')
 
 router.use('/',UserRouter)

 module.exports = router;