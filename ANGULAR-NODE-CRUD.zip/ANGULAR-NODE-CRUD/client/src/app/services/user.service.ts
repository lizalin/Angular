import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { User } from 'src/app/models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  apiURL = environment.apiUrl

  constructor(private httpClient: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  getAll(): Observable<User[]> {
    return this.httpClient.get<User[]>(this.apiURL + '/users/')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  create(userData): Observable<User> {
    return this.httpClient.post<User>(this.apiURL + '/user/', userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  find(id): Observable<User> {
    return this.httpClient.get<User>(this.apiURL + '/user/' + id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  update(id, userData): Observable<User> {
    return this.httpClient.put<User>(this.apiURL + '/user/' + id, userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  delete(id) {
    return this.httpClient.delete<User>(this.apiURL + '/user/' + id, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }


  errorHandler(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
