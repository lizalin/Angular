import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  userlist:User[] = [];
  constructor(private userService: UserService,private router:Router) { }

  ngOnInit(): void {
    this.userService.getAll().subscribe((data: User[])=>{
      this.userlist = data;
    })  
  }
  
  deleteUser(id){
    this.userService.delete(id).subscribe(res => {
         this.userlist = this.userlist.filter(item => item.id !== id);
    })
  }

  editUser(id){
    this.router.navigate(['/addUser'], { queryParams: { id: id} });
  }

}
