import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  submitted = false;
  submitBtnLbl:string = 'Submit';
  id:number;
  user:User;

  userForm = this.fb.group({
    name: ['', Validators.required],
    phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
    company: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]]
  });

  constructor(private fb: FormBuilder,private userService: UserService,private router: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if(params.hasOwnProperty('id')){
        this.id = params.id;
        if(Number(this.id)>0){
          this.userService.find(this.id).subscribe(res => {
            this.user = res;
            this.userForm.patchValue(this.user);
            this.submitBtnLbl = 'Update';
          })
        }
      }
    })
  }

  get f() { return this.userForm.controls; }

  onSubmit() {
    this.submitted = true;
    
    if (this.userForm.invalid) {
      return;
    }

    if(this.id!=undefined && Number(this.id)>0){
      this.userService.update(this.id,this.userForm.value).subscribe(res => {
        this.router.navigate(['/']);
      })
    }else{
      this.userService.create(this.userForm.value).subscribe(res => {
        this.router.navigate(['/']);
      })
    }
    
  }

  resetForm() {
    this.userForm.reset();
  }
}
