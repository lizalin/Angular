import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddUserComponent } from './pages/add-user/add-user.component';
import { PagenotfoundComponent } from './pages/pagenotfound/pagenotfound.component';
import { UserdetailsComponent } from './pages/userdetails/userdetails.component';
import { UserlistComponent } from './pages/userlist/userlist.component';


const routes: Routes = [
  {path:'userlist',component:UserlistComponent},
  {path:'userdetails/:id',component:UserdetailsComponent},
  {path:'addUser',component:AddUserComponent},
  /*{
    path:'userdetails',
    // component:UserdetailsComponent,
    pathMatch:'prefix',
    children:[
      {path:':name',component:UserdetailsComponent},
      {path:':name/:id',component:UserdetailsComponent},
    ]
  },*/
  {path:'',redirectTo:'/userlist',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
