export interface User {
    id: number;
    name: string;
    phone: string;
    company: string;
    email: string;
}
