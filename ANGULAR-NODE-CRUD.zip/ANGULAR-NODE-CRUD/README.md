# ANGULAR-NODE -RUD

> Angular Node Crud With Express and Mysql

- routes mapping via [express-routes-mapper](https://github.com/aichbauer/express-routes-mapper)
- built with [npm sripts](#npm-scripts)

## Install and Use

- cd into client & api both folder
- npm install in both folder

#local node dev server runs on 3200 port
- npm run dev

## Folder Structure

This has 1 root directory and 2 main sub directories:
- client - Angular App
- api    - Node App

Inside Node App following subfolders are there
- app - contains all controllers, models, config, routes, utils etc.
- config - contains all the database configuration for development,testing,production
- models - contains all db connection related classes
- controllers - core logics will be written in controllers 
- routes - all the custom routes will be written here

### other commands

- `npm run dev` - simply start the server with a watcher
- `ng serve`    - simply start the angular app

