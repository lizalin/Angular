import { GrdFilterPipe } from './grd-filter.pipe';

describe('GrdFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GrdFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
