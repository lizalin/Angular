import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpserviceService {

  constructor(private httpClient: HttpClient) { }

  getEmployee(): Observable<any> {
    return this.httpClient.get("./assets/emplist.json");
  }

  authenticate(): Observable<any> {
    return this.httpClient.get("./assets/userCredential.json");
  }
}
