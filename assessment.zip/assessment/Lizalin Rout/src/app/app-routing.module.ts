import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeelistComponent } from './pages/employeelist/employeelist.component';
import { LoginComponent } from './pages/login/login.component';
import { EmployeedetailsComponent } from './pages/employeedetails/employeedetails.component';
import { AuthGuard } from './core/auth.guard';


const routes: Routes = [
  {path: '',redirectTo: 'login',pathMatch: 'full'},
  {path: 'login',component: LoginComponent},
  {path: 'emplist',component: EmployeelistComponent, canActivate: [AuthGuard]},
  {path: 'empdetails/:id',component: EmployeedetailsComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
