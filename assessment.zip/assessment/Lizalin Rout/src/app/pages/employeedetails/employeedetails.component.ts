import { Component, OnInit } from '@angular/core';
import { HttpserviceService } from 'src/app/core/httpservice.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {
  mobileno:string;
  empDtls:any;
  constructor(private httpserviceService:HttpserviceService,private route:ActivatedRoute, private router:Router) {
    this.route.params.subscribe(res => {
      this.mobileno = res.id;
      if(this.mobileno.length > 0){
        this.getemployeeDtls();
      }
    })
   }

  ngOnInit(): void {
  }

  getemployeeDtls(){
    this.httpserviceService.getEmployee().subscribe(res => {
      if(res != undefined && res.length > 0){
        let resFilter = res.filter(data => data.Mobile == this.mobileno);
        if(resFilter.length>0){
          this.empDtls = resFilter[0];
        }
      }
    })
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/']);
  }

  

}
