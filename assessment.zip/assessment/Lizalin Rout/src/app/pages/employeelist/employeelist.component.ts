import { Component, OnInit } from '@angular/core';
import { HttpserviceService } from 'src/app/core/httpservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
  employees:any = [];
  searchTxt:string;
  constructor(private httpserviceService:HttpserviceService,private router:Router) { 
    this.allEmployee();
  }

  ngOnInit(): void {
  }

  allEmployee(){
    this.httpserviceService.getEmployee().subscribe(res => {
      if(res!=undefined && res.length>0){
        this.employees = res;
      }
    })
  }

  getempdetails(data){
    this.router.navigate(['/empdetails',data.Mobile]);
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/']);
  }

}
