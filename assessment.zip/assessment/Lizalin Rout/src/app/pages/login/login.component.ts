import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpserviceService } from 'src/app/core/httpservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login = this.fb.group({
    mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
    password: ['', [Validators.required]]
  });
  submitted:boolean = false;
  constructor(private fb:FormBuilder, private httpserviceService:HttpserviceService,private router:Router) { }

  ngOnInit(): void {
  }

  doLogin(){
    this.submitted = true;
    if(this.login.invalid){
      return false;
    }
    this.httpserviceService.authenticate().subscribe(res =>{
      if(res != undefined && res.length > 0){
        let validData = res.filter(data => data.mobile == this.login.value.mobile && data.password == this.login.value.password)
        if(validData.length == 1){
          localStorage.setItem("token",btoa(validData));
          this.router.navigate(['/emplist']);
        }
      }
    })
  }

  get f(){
    return this.login.controls;
  }

}
