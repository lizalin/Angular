import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthGuard implements CanActivate {
  // adminEmail:any = "supAdmin";
  // adminPass:any = "admin@123";
  // token:any = "query@admin#123"
  constructor(private router : Router){}
  canActivate(){
    // if(this.router.getCurrentNavigation().extras.state != undefined){
    //   let email = this.router.getCurrentNavigation().extras.state.email;
    //   let password = this.router.getCurrentNavigation().extras.state.password;
    //   let loginToken = localStorage.getItem('loginToken');
    //   if(loginToken == this.token){
    //     return true;
    //   }else{
    //     return false;
    //   } 
    // }else{
    //   this.router.navigate(['/loginM'])
    // } 
    let loginToken = localStorage.getItem('loginToken');
    if(loginToken != undefined && loginToken.length>0 ){
      return true;
    }else{
      this.router.navigate(['/'])
    }
  }
}
