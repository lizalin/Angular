import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginMComponent } from './login-m.component';

const routes: Routes = [{ path: '', component: LoginMComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginMRoutingModule { }
