import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { FormBuilder,FormsModule } from '@angular/forms';
import { LoginService } from 'src/app/logiM/login.service'

@Component({
  selector: 'app-login-m',
  templateUrl: './login-m.component.html',
  styleUrls: ['./login-m.component.css']
})
export class LoginMComponent implements OnInit {
  login = this.fb.group({
    "email" : [''],
    "password" : ['']
  });
  constructor(private fb : FormBuilder,private router : Router,private LS:LoginService) { }

  ngOnInit(): void {
    let loginToken = localStorage.getItem('loginToken');
    if(loginToken != undefined && loginToken.length > 0){
      this.router.navigate(['/dashboard']);
    }
  }

  onSubmit(){
    let email = this.login.value.email;
    let password = this.login.value.password;
    let data = {
      uName : email,
      pass : password
    }
    let loginValidate = this.LS.authenticate(data);
    // let data : NavigationExtras = {
    //   state : {
    //     email : email,
    //     password : password
    //   }
    // }
    if(loginValidate){
      this.router.navigate(['/dashboard']);
    } 
  }

}
