import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { LoginMRoutingModule } from './login-m-routing.module';
import { LoginMComponent } from './login-m.component';


@NgModule({
  declarations: [LoginMComponent],
  imports: [
    CommonModule,
    LoginMRoutingModule,
    ReactiveFormsModule
  ]
})
export class LoginMModule { }
