import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  uName:any = "supAdmin";
  pass:any = "admin@123"
  constructor() { }

  authenticate(data){
    if(data.uName == this.uName && data.pass == this.pass){
      localStorage.setItem('loginToken',this.encrypt(data));
      return true;
    }else{
      return false;
    }
  }

  encrypt(data){
    return window.btoa(data);
  }

  decrypt(data){
    return window.atob(data);
  }

}
