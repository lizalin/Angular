import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginAuthGuard } from './login-auth.guard';
import { LoginMComponent } from './login-m/login-m.component';


const routes: Routes = [
  {path : '',redirectTo : 'loginM',pathMatch : 'full'},
  { path: 'loginM', loadChildren: () => import('./login-m/login-m.module').then(m => m.LoginMModule) },
  { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule),canActivate : [LoginAuthGuard] },
  { path: 'userprofile', loadChildren: () => import('./userprofile/userprofile.module').then(m => m.UserprofileModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
