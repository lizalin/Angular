import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationStart, NavigationExtras, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  userSelectId:any;
  constructor(private route:ActivatedRoute,private router:Router ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(data => {
      console.log(data);
      this.userSelectId = data.name;
      // const currentState = this.router.getCurrentNavigation();
      //   console.log(currentState);

    })
    // let name = this.route.snapshot.paramMap.get('id');
    // console.log(name);
    // this.userSelectId = name;
  }

}
