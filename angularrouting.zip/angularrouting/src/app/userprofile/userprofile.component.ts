import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  allUsers:any[] = [];
  constructor(private route:ActivatedRoute,private router:Router) { 
    this.allUsers = [
      {id:1,name:"Lizalin Rout"},
      {id:2,name:"Abhiram Samntara"},
      {id:3,name:"Chinmayee Sahoo"},
      {id:4,name:"Swagatika Sahoo"},
      {id:5,name:"Subhashree Das"},
    ];

  }
  ngOnInit(): void {
    // this.route.queryParams.subscribe(data => {
    //   console.log(data);
    // })
    // let id = this.route.snapshot.paramMap.get('id');
    // console.log(id);
  }

  navigateto(){
    // this.router.navigate(['/userDetails'],[{id:"1"}]);
    // this.router.navigate(['/userDetails'], { queryParams: { page: 1 } });

  //   let objToSend: NavigationExtras = {
  //     queryParams: {
  //     id: 1,
  //     productName: 'Netgear Cable Modem',
  //     productCode: 'CM700',
  //     description: 'Netgear Cable Modem compatible with all cables',
  //     prodRating: 4.9
  //     },
  //     // skipLocationChange: false,
  //     // fragment: 'top' 
  // };


  // this.router.navigate(['/userDetails'], { 
  // state: { userDetails: objToSend }
  // });

  // this.router.navigate(['/userDetails'],objToSend);

  }

  sendData(userDtls){
    // console.log(userDtls);
    let objToSend : NavigationExtras = {
      queryParams : {
        name : userDtls.name,
        id : userDtls.id
      }
    }
    this.router.navigate(['/userDetails'],objToSend)
  }

}
