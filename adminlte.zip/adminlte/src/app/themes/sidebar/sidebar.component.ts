import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  constructor() { }
  user:any;
  menus:any;
  ngOnInit(): void {
    if(localStorage.getItem('user') != undefined){
      this.user = JSON.parse(localStorage.getItem('user'));
    }
    if(localStorage.getItem('menus') != undefined){
      this.menus = JSON.parse(localStorage.getItem('menus'));
    }
  }
}
