import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaselayoutComponent } from 'src/app/themes/baselayout/baselayout.component';
import { FooterComponent } from 'src/app/themes/footer/footer.component';
import { HeaderComponent } from 'src/app/themes/header/header.component';
import { SidebarComponent } from 'src/app/themes/sidebar/sidebar.component';
import { BreadcumbComponent } from './breadcumb/breadcumb.component';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [
    BreadcumbComponent,
    BaselayoutComponent,
    FooterComponent,
    HeaderComponent,
    SidebarComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ]
})
export class ThemesModule { }
