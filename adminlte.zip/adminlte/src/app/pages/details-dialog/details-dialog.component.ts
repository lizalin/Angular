import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-details-dialog',
  templateUrl: './details-dialog.component.html',
  styleUrls: ['./details-dialog.component.css']
})
export class DetailsDialogComponent implements OnInit {
  modalDetailsData:any;
  constructor(private modalDetails:NgbActiveModal) { }

  ngOnInit(): void {
  }

  respondModal(type){
    this.modalDetails.close(type);
  }

}
