import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewproductComponent } from './viewproduct/viewproduct.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from 'src/app/core/pipes/filter.pipe';
import { GridFilterPipe } from 'src/app/core/pipes/grid-filter.pipe';
import { OrderByPipe } from 'src/app/core/pipes/order-by.pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { AddproductComponent } from './addproduct/addproduct.component';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: 'viewproducts',
    component: ViewproductComponent
  },
  {
    path: 'addproducts',
    component: AddproductComponent
  }
]

@NgModule({
  declarations: [
    ViewproductComponent,
    FilterPipe,
    GridFilterPipe,
    OrderByPipe,
    AddproductComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule
  ]
})
export class ProductModule { }
