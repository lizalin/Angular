import { Component, OnInit, Input } from '@angular/core';
import { UserService } from 'src/app/core/service/common/user.service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { DialogComponent } from 'src/app/core/common/dialog/dialog.component';
import { NotificationService } from 'src/app/core/service/common/notification.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-viewproduct',
  templateUrl: './viewproduct.component.html',
  styleUrls: ['./viewproduct.component.css']
})
export class ViewproductComponent implements OnInit {
  allproducts: any = [];
  searchText: string;
  //sorting
  key: string = 'name'; //set default
  reverse: boolean = false;
  direction: number;
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
    this.direction = this.reverse ? 1 : -1;
  }

  //Pagination Start
  public showrecord: boolean = true;
  public list: any = [
    { name: '5', value: 5 },
    { name: '10', value: 10 },
    { name: '20', value: 20 },
    { name: '100', value: 100 }
  ];
  p: number = 1;
  limit: number = 10;
  totalRecord: number = 0;
  fromRecord: number = 0;
  toRecord: number = 0;
  changenoitem(noi: number) {
    this.limit = noi;
    this.p = 1;
    this.showRecordCount();
  }

  showRecordCount() {
    this.fromRecord = ((this.limit * this.p) - this.limit) + 1;
    let max = this.limit * this.p;
    if (max > this.totalRecord) {
      max = this.totalRecord;
    }
    this.toRecord = max;
  }

  getPage(page: number) {
    this.p = page;
    this.showRecordCount();
  }

  filterGrid() {
    this.p = 1;
    this.showRecordCount();
  }
  //Pagination End

  constructor(private userService: UserService, private modalService:NgbModal, private notificationService:NotificationService, private router:Router) {
    this.fetchProducts();
  }

  ngOnInit(): void {
  }

  fetchProducts() {
    this.userService.getAllProducts().subscribe(res => {
      this.allproducts = res.data
      this.totalRecord = this.allproducts.length;
      this.showRecordCount();
    })
  }

  @Input() modalData: any = { title: '', message: '', yesbtnlbl: '', nobtnlbl: '' };

  delete(id) {
    
    let ngbModalOptions: NgbModalOptions ={ windowClass: 'modal-holder',centered: true ,backdrop: 'static',keyboard: false};

    this.modalData.title = 'Confirm';
    this.modalData.message = 'Do you want to delete the record ?';
    this.modalData.yesbtnlbl = 'Yes';
    this.modalData.nobtnlbl = 'No';

    const modalRef = this.modalService.open(DialogComponent,ngbModalOptions);
    modalRef.componentInstance.modalData = this.modalData;

    modalRef.result.then((result) => {
      console.log(result);
      if (result!=undefined && result=='Yes') {
        this.userService.deleteProduct(id).subscribe(res => {
          if(res.success){
            this.notificationService.showSuccess('Product deleted successfully.','');
            this.fetchProducts();
          }
        })
      }
    });
  }

  editProduct(id){
    this.router.navigate(['/base/pages/product/addproducts'], { queryParams : { id:id } });
  }

}
