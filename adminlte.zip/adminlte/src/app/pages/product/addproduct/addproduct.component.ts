import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from 'src/app/core/service/common/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from 'src/app/core/service/common/notification.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  submitted:boolean = false;
  productId:number = 0;
  products = this.fb.group({
    name : ['',[Validators.required]],
    sku : ['',[Validators.required]],
    price : ['',[Validators.required]],
    quantity : ['',[Validators.required]]
  });
  constructor(
    private fb:FormBuilder,
    private userService:UserService,
    private router:Router,
    private notificationService:NotificationService,
    private activatedRoute:ActivatedRoute
    ) { 
      this.activatedRoute.queryParams.subscribe(params => {
        if(params.hasOwnProperty('id')){
          this.productId = params.id;
          this.productDetails();
        }
      })
    }

  ngOnInit(): void {
  }

  addProduct(){
    console.log(this.products.value)
    this.submitted = true;
    if(this.products.invalid){
      return;
    }
    if(this.productId == 0){
      this.userService.createProduct(this.products.value).subscribe(res => {
        this.router.navigate(['/base/pages/product/viewproducts']);
        this.notificationService.showSuccess('Product added successfully','');
      })
    }else{
      this.userService.updateProduct(this.productId,this.products.value).subscribe(res => {
        this.router.navigate(['/base/pages/product/viewproducts']);
        this.notificationService.showSuccess('Product updated successfully','');
      })
    }
  }

  productDetails(){
    this.userService.getProduct(this.productId).subscribe(res => {
      this.products.patchValue(res);
    })
  }

  get f(){
    return this.products.controls;
  }

}
