import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/core/service/common/user.service';
import { NotificationService } from 'src/app/core/service/common/notification.service';
@Component({
  selector: 'app-menus',
  templateUrl: './menus.component.html',
  styleUrls: ['./menus.component.css']
})
export class MenusComponent implements OnInit {
  menu = this.fb.group({
    parent_id: ['0'],
    name: ['',[Validators.required]],
    link: ['',[Validators.required]],
    icon: ['',[Validators.required]],
  });
  submitted:boolean = false;
  menuId:number = 0;
  btntab:string = 'Add';
  btnsubmit:string = 'Submit';
  allmenus:any;
  constructor(
    private fb:FormBuilder,
    private router:Router,
    private userService:UserService,
    private notificationService:NotificationService,
    private activatedRoute:ActivatedRoute
    ) { 
      this.activatedRoute.queryParams.subscribe(params => {
        if(params.hasOwnProperty('id')){
          this.menuId = params.id;
          this.menuDetails();
        }
      })
      if(this.menuId>0){
        this.btntab = 'Update';
        this.btnsubmit = 'Update';
      }
      this.getMenus();
    }

  ngOnInit(): void {
  }

  menuDetails(){
    this.userService.getMenu(this.menuId).subscribe(res => {
      this.menu.patchValue(res)
    })
  }

  addGl(){
    this.submitted = true;
    
    if (this.menu.invalid) {
      return;
    }
    if(this.menuId > 0){
      this.userService.updateMenu(this.menuId,this.menu.value).subscribe(res => {
        this.router.navigate(['/base/pages/viewmenus'])
        this.notificationService.showSuccess('Menu updated successfully','');
      })
    }else{
      this.userService.createMenu(this.menu.value).subscribe(res => {
        this.router.navigate(['/base/pages/viewmenus'])
        this.notificationService.showSuccess('Menu added successfully. Please login again veiw the menu in sidebar','');
      });
    }
  }

  getMenus(){
    this.userService.allMenu().subscribe(res => {
      this.allmenus = res.data;
    })
  }

  get f() { return this.menu.controls; }

}
