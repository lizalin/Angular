import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
  imgUrl:any = './assets/profile.jpg';
  degrees = ['B.E.', 'M.E.', 'B.Com', 'M.Com'];
  resume = this.fb.group({
    name : [''],
    address : [''],
    phone : [''],
    email : [''],
    socialProfile : [''],
    skills : this.fb.array([this.newSkill()]),
    experience : this.fb.array([this.newExperience()]),
    education : this.fb.array([this.newEducation()]),
    otherDetails : ['']
  });
  constructor(private fb:FormBuilder) { }

  get skills() : FormArray{
    return this.resume.get('skills') as FormArray;
  }

  newSkill(): FormGroup{
    return this.fb.group({
      skill : ['']
    })
  }

  addSkills(){
    this.skills.push(this.newSkill());
  }

  removeSkill(i){
    this.skills.removeAt(i);
  }

  get experience() : FormArray{
    return this.resume.get('experience') as FormArray;
  }

  newExperience() : FormGroup{
    return this.fb.group({
      employer : [''],
      jobDesc : [''],
      jobTitle : [''],
      expInMonth : ['']
    });
  }

  addExperience(){
    this.experience.push(this.newExperience());
  }

  removeExperience(i){
    this.experience.removeAt(i);
  }

  get education() : FormArray{
    return this.resume.get('education') as FormArray;
  }

  newEducation() : FormGroup{
    return this.fb.group({
      degree : [''],
      schoolCollege : [''],
      passYear : [''],
      percentage : ['']
    });
  }

  addEducation(){
    this.education.push(this.newEducation());
  }

  removeEducation(i){
    return this.education.removeAt(i);
  }

  getResumeData(){
    console.log(this.resume.value);
  }

  ngOnInit(): void {
  }

}
