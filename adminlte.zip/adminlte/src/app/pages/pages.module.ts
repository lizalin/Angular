import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsComponent } from 'src/app/pages/forms/forms.component';
import { DashboardComponent } from 'src/app/pages/dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { MenusComponent } from './menus/menus.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ViewMenusComponent } from './view-menus/view-menus.component';
import { ToastrModule } from 'ngx-toastr';
import { ProductModule } from './product/product.module';
import { DetailsDialogComponent } from './details-dialog/details-dialog.component';

const routes: Routes = [
		{
      path: 'dashboard',
      component: DashboardComponent
    },
    {
      path: 'forms',
      component: FormsComponent
    },
    {
      path: 'menus',
      component: MenusComponent
    },
    {
      path: 'viewmenus',
      component: ViewMenusComponent
    },
    { path: 'product', loadChildren: () => import('src/app/pages/product/product.module').then(m => m.ProductModule) }
];


@NgModule({
  declarations: [
    FormsComponent,
    DashboardComponent,
    MenusComponent,
    ViewMenusComponent,
    DetailsDialogComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    ToastrModule,
    ProductModule
  ]
})
export class PagesModule { }
