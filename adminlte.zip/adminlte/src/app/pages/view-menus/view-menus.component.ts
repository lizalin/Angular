import { Component, Input, OnInit } from '@angular/core';
import { UserService } from 'src/app/core/service/common/user.service';
import { NotificationService } from 'src/app/core/service/common/notification.service';
import { Router } from '@angular/router';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { DialogComponent } from 'src/app/core/common/dialog/dialog.component';
import { DetailsDialogComponent } from '../details-dialog/details-dialog.component';

@Component({
  selector: 'app-view-menus',
  templateUrl: './view-menus.component.html',
  styleUrls: ['./view-menus.component.css']
})
export class ViewMenusComponent implements OnInit {
  menus:any = [];
  constructor(
    private userService:UserService, 
    private notificationService:NotificationService, 
    private modalService:NgbModal,
    private router:Router
    ) {
    this.getMenus();
   }

  ngOnInit(): void {
    
  }

  getMenus(){
    this.userService.allMenu().subscribe(res => {
      this.menus = res.data;
    })
  }

  edit(id){
    this.router.navigate(['/base/pages/menus'], { queryParams: { id: id} });
  }

  //Modal
  @Input() modalData: any = { title: '', message: '', yesbtnlbl: '', nobtnlbl: '' };
  delete(id) {
    
    let ngbModalOptions: NgbModalOptions ={ windowClass: 'modal-holder',centered: true ,backdrop: 'static',keyboard: false};

    this.modalData.title = 'Confirm';
    this.modalData.message = 'Do you want to delete the record ?';
    this.modalData.yesbtnlbl = 'Yes';
    this.modalData.nobtnlbl = 'No';

    const modalRef = this.modalService.open(DialogComponent,ngbModalOptions);
    modalRef.componentInstance.modalData = this.modalData;

    modalRef.result.then((result) => {
      console.log(result);
      if (result!=undefined && result=='Yes') {
        this.userService.deleteMenu(id).subscribe(res => {
          if(res.success){
            this.notificationService.showSuccess('Menu deleted successfully. Please login again veiw the changes in sidebar','');
            this.getMenus();
          }
        })
      }
    });
  }

  @Input() modalDetailsData: any = { title: '', message: '', yesbtnlbl: '', nobtnlbl: '' };
  details(id) {
    
    let ngbModalOptions: NgbModalOptions ={ windowClass: 'modal-holder',centered: true ,backdrop: 'static',keyboard: false};

    this.modalDetailsData.title = 'Child Menu Details';
    let details = this.menus.filter(data => data.id == id);
    this.modalDetailsData.message = details[0].childMenu;
    this.modalDetailsData.nobtnlbl = 'Close';

    const modalRef = this.modalService.open(DetailsDialogComponent,ngbModalOptions);
    modalRef.componentInstance.modalDetailsData = this.modalDetailsData;

  }

}
