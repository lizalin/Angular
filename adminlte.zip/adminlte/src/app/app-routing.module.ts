import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { BaselayoutComponent } from 'src/app/themes/baselayout/baselayout.component';


const routes: Routes = [
  { path: 'auth', loadChildren: () => import('src/app/auth/auth.module').then(m => m.AuthModule) },
  {
    path: 'base',
    component: BaselayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'pages', loadChildren: () => import('src/app/pages/pages.module').then(m => m.PagesModule) },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
