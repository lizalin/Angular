import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  modalData:any;
  constructor(private modal:NgbActiveModal) { }

  ngOnInit(): void {
  }

  respondModal(type){
    this.modal.close(type);
  }

}
