import { GridFilterPipe } from './grid-filter.pipe';

describe('GridFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GridFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
