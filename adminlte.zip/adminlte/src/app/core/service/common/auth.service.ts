import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse,HttpHeaders, HttpBackend } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  apiURL = environment.apiUrl;
  constructor(private httpClient: HttpClient, private httpBackend:HttpBackend) {
    this.httpClient = new HttpClient(httpBackend);
   }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  authenticate(userData): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + 'login', userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  register(userData): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + 'register', userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  encrypt(data){
    return window.btoa(data);
  }

  decrypt(data){
    return window.atob(data);
  }

  errorHandler(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
