import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  apiURL = environment.apiUrl;
  constructor(private httpClient: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  logout(): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'logout')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  profile(): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'profile')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  createMenu(userData): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + 'menus', userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  allMenu(): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'menus')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  deleteMenu(id): Observable<any> {
    return this.httpClient.delete<any>(this.apiURL + 'menus' + '/'+ id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  getMenu(id): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'menus' + '/'+ id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  updateMenu(id,userData): Observable<any> {
    return this.httpClient.put<any>(this.apiURL + 'menus' + '/'+ id,userData)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  getAllProducts(): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'products')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  deleteProduct(id): Observable<any> {
    return this.httpClient.delete<any>(this.apiURL + 'products' + '/'+ id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  createProduct(userData): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + 'products', userData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  getProduct(id): Observable<any> {
    return this.httpClient.get<any>(this.apiURL + 'products' + '/'+ id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  updateProduct(id,userData): Observable<any> {
    return this.httpClient.put<any>(this.apiURL + 'products' + '/'+ id,userData)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  errorHandler(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
