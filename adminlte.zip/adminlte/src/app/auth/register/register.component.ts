import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/service/common/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register = this.fb.group({
    name : ['',[Validators.required]],
    email : ['',[Validators.required,Validators.email]],
    password : ['',[Validators.required]],
    repassword : ['',[Validators.required]],
    terms : ['',[Validators.required]]
  });
  submitted:boolean = false;
  regSucc:boolean = false;
  constructor(private fb:FormBuilder, private authService:AuthService, private router:Router) { }

  ngOnInit(): void {
  }

  doRegister(){
    this.submitted = true;
    
    if (this.register.invalid) {
      return;
    }
    if(this.register.value.password == this.register.value.repassword){
      this.authService.register(this.register.value).subscribe(res=>{
        if(res != undefined){
          this.regSucc = true;
          // this.router.navigate(['/base/pages/dashboard']);
        }
      });
    }
    
  }

  get f() { return this.register.controls; }

}
