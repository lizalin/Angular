import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/service/common/auth.service';
import { UserService } from 'src/app/core/service/common/user.service';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/core/service/common/loader.service';
import { NotificationService } from 'src/app/core/service/common/notification.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });
  submitted: boolean = false;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private userService: UserService,
    private loaderService: LoaderService,
    private notificationService: NotificationService
  ) { }

  ngOnInit(): void {
  }

  doLogin() {
    this.submitted = true;

    if (this.login.invalid) {
      return;
    }
    this.loaderService.display(true);
    this.authService.authenticate(this.login.value).subscribe(res => {
      if (res != undefined && res.hasOwnProperty('token') && res.token.length>0) {
        localStorage.setItem('token', res.token);
        this.userService.allMenu().subscribe(menus => {
          if(menus!=undefined && menus.data.length>0){
            localStorage.setItem('menus',JSON.stringify(menus.data));
          }
        });
        this.userService.profile().subscribe(details => {
          localStorage.setItem('user', JSON.stringify(details.user));
          this.router.navigate(['/base/pages/dashboard']);
          this.loaderService.display(false);
          this.notificationService.showSuccess('Login Successfully','');
        });
      } else {
        this.loaderService.display(false);
      }
    })
  }

  get f() { return this.login.controls; }

}
