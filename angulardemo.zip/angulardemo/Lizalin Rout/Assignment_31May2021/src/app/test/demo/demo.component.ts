import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss']
})
export class DemoComponent implements OnInit {
  str:string = "This is my first Interpollation";
  rangeTxt:number = 0;
  rectStyle:string;
  name:string = "Lizalin Rout";
  email:string = "lizalin.rout@csm.co.in";
  company:string = "CSM";
  website:string = 'https://csm.co.in';
  clsHide:boolean = true; 
  thankMsg:boolean = true; 
  clsFrmHide:boolean = false;
  datas = [];
  isScaled:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  funRange(){
    console.log(this.rangeTxt);
    this.rectStyle = 'border-radius:'+ this.rangeTxt +'%';
  }

  frmSubmit(){
    this.name = this.name;
    this.email = this.email;
    this.company = this.company;
    this.website = this.website;
    this.clsHide = !this.clsHide;
    this.clsFrmHide = !this.clsFrmHide ;
    this.thankMsg = !this.thankMsg;
    if(this.name!=''&&this.email!=''&&this.company!=''&&this.website!=''){
      this.datas.push({name:this.name,email:this.email,company:this.company,website:this.website});
    }

  }

  frmReset(){
    this.name = '';
    this.email = '';
    this.company = '';
    this.website = '';
    this.clsHide = !this.clsHide;
    this.clsFrmHide = !this.clsFrmHide ;
    this.thankMsg = !this.thankMsg;
  }

  editRow(editData){
    console.log(editData);
    this.name = editData.name;
    this.email = editData.email;
    this.company = editData.company;
    this.website = editData.website;
    this.clsHide = !this.clsHide;
    this.clsFrmHide = !this.clsFrmHide ;
    this.thankMsg = !this.thankMsg;
  }

  // @HostListener ('mouseenter') mouseenter(){
  //   console.log(1);
  //   this.isScaled = true;
  // }

  // @HostListener ('mouseleave') mouseleave(){
  //   this.isScaled = false;
  // }

  @HostListener('document:mouseover', ['$event'])
    mouseover(event) {
        if(event.target.matches('.effectCls')) {
          console.log(1);
          this.isScaled = true;
        }
    }

    @HostListener('document:mouseout', ['$event'])
    mouseout(event) {
        if(event.target.matches('.effectCls')) {
          console.log(1);
          this.isScaled = false;
        }
    }

}
