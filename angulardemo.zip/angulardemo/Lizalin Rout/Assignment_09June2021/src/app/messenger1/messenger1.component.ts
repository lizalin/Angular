import { Component, OnInit } from '@angular/core';
import { MessengerService } from '../messenger.service';

@Component({
  selector: 'app-messenger1',
  templateUrl: './messenger1.component.html',
  styleUrls: ['./messenger1.component.scss']
})
export class Messenger1Component implements OnInit {
  message:any;
  msgRes:any = [];
  allMsg:any = [];
  constructor(public msgServiceRef:MessengerService) { }

  ngOnInit(): void {
    this.msgServiceRef.getmessage1.subscribe((res) => {
      this.msgRes = res;
    })
  }

  sendData(){
    if(this.message.trim()){
      this.allMsg.push({"messages":this.message});
    }
    this.msgServiceRef.setmessage(this.allMsg);
  }

}
