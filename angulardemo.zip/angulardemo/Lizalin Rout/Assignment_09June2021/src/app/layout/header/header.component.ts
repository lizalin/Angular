import { Component, OnInit } from '@angular/core';
import { $ } from 'protractor';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  brandText:any = "breaking thought barriers";
  menuName:any = "";
  num1:number = 5;
  num2:number = 5;
  res:number;
  // menus:any = ['Publications','Industries','Services','Career','Solution'];
  menus:any = [
    {name:'Publications',link:'Publications'},
    {name:'Industries',link:'Industries'},
    {name:'Services',link:'Services'},
    {name:'Career',link:'Career'},
    {name:'Solution',link:'Solution'},
    {name:'Practice',link:'Practice'}
  ];
  constructor() { }

  ngOnInit(): void {
  }

  getMenuName(menuName){
    console.log(menuName);
    this.menuName = menuName;
  }

  funAdd(){
    this.res = Number(this.num1) + Number(this.num2);
    console.log(this.res);
  }
  funSub(){
    this.res = this.num1-this.num2;
    console.log(this.res);
  }
  funMul(){
    this.res = this.num1*this.num2;
    console.log(this.res);
  }
  funDivide(){
    this.res = this.num1/this.num2;
    console.log(this.res);
  }

}
