import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {
  name:string;
  address:string;
  data:any;
  constructor() { }

  ngOnInit(): void {
  }

  funSubmit(){
    this.data = {"name":this.name,"address":this.address};
  }

}
