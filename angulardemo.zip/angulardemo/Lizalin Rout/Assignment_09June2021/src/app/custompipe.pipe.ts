import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe'
})
export class CustompipePipe implements PipeTransform {

  transform(message: any, smily: any): any {
    return message.length > smily?message.substring(0,smily)+'....':message;
  }

}
