import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {
  constructor(public Element: ElementRef) {}

  @HostListener ('mouseenter') mouseenter(){
    this.Element.nativeElement.style.transform = 'scale(1.5)';
    this.Element.nativeElement.style.fontweight = 'bold';
    this.Element.nativeElement.style.padding = '10px';
    this.Element.nativeElement.style.background = 'pink';
  }
  @HostListener ('mouseleave') mouseleave(){
    this.Element.nativeElement.style = '';
  }

}
