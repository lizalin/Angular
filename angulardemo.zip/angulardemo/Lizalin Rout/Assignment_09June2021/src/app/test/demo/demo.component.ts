import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss']
})
export class DemoComponent implements OnInit {
  str:string = "This is my first Interpollation";
  rangeTxt:number = 0;
  rectStyle:string;
  name:string = "Lizalin Rout";
  email:string = "lizalin.rout@csm.co.in";
  company:string = "CSM";
  website:string = 'https://csm.co.in';
  datas = [];
  isScaled:boolean = false;
  indx:number;
  isShownMsg:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  funRange(){
    console.log(this.rangeTxt);
    this.rectStyle = 'border-radius:'+ this.rangeTxt +'%';
  }

  frmSubmit(){
    if(this.name.trim()&&this.email.trim()&&this.company.trim()&&this.website.trim()){
      if(this.indx != undefined && Number(this.indx)>=0){
        this.datas[this.indx].name=this.name;
        this.datas[this.indx].email=this.email;
        this.datas[this.indx].company=this.company;
        this.datas[this.indx].website=this.website;
        this.indx = -1;
      }else{
        this.datas.push({name:this.name,email:this.email,company:this.company,website:this.website});
      }
    }
    this.isShownMsg=true;
  }

  frmReset(){
    this.name = '';
    this.email = '';
    this.company = '';
    this.website = '';
    this.isShownMsg=false;
  }

  editRow(indx,editData){
    console.log(indx);
    this.indx = indx;
    this.name = editData.name;
    this.email = editData.email;
    this.company = editData.company;
    this.website = editData.website;
    this.isShownMsg=false;
  }

  // @HostListener ('mouseenter') mouseenter(){
  //   console.log(1);
  //   this.isScaled = true;
  // }

  // @HostListener ('mouseleave') mouseleave(){
  //   this.isScaled = false;
  // }

  @HostListener('document:mouseover', ['$event'])
    mouseover(event) {
        if(event.target.matches('.effectCls')) {
          this.isScaled = true;
        }
    }

    @HostListener('document:mouseout', ['$event'])
    mouseout(event) {
        if(event.target.matches('.effectCls')) {
          this.isScaled = false;
        }
    }

}
