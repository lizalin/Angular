import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.scss']
})
export class AssignmentComponent implements OnInit {
  name:string;
  email:string;
  company:string;
  website:string;
  empDatas = [];
  indx:number;
  isShown:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  btnSubmit(){
    if(this.name.trim()&&this.email.trim()&&this.company.trim()&&this.website.trim()){
    if(this.indx != undefined && Number(this.indx)>=0){
      this.empDatas[this.indx].name=this.name;
      this.empDatas[this.indx].email=this.email;
      this.empDatas[this.indx].company=this.company;
      this.empDatas[this.indx].website=this.website;
      this.indx = -1;
    }else{
      this.empDatas.push({name:this.name,email:this.email,company:this.company,website:this.website});
    }
    this.isShown = true;
  }
    this.name = '';
    this.email = '';
    this.company = '';
    this.website = '';
  }

  btnEdit(indx,empData){
    this.indx = indx;
    this.name = empData.name;
    this.email = empData.email;
    this.company = empData.company;
    this.website = empData.website;
  }

  textChange(){
    console.log(this.indx);
    if(this.indx != undefined && Number(this.indx)>=0){
      this.empDatas[this.indx].name=this.name;
      this.empDatas[this.indx].email=this.email;
      this.empDatas[this.indx].company=this.company;
      this.empDatas[this.indx].website=this.website;
    }
  }

}
