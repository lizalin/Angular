import { Component, OnInit } from '@angular/core';
import { LocalstorageService } from '../localstorage.service'
@Component({
  selector: 'app-parentresume',
  templateUrl: './parentresume.component.html',
  styleUrls: ['./parentresume.component.scss']
})
export class ParentresumeComponent implements OnInit {
  fname: any;
  lname: any;
  profession: any;
  city: any;
  state: any;
  zipcode: any;
  phone: any;
  email: any;
  dataArray: any = [];
  retrievedObject: number = 0;
  currentRefNo: any = '';
  datasaved: number = 0;
  buttonLbl:string = 'Submit';

  constructor(private LocalstorageServiceRef: LocalstorageService) { }

  ngOnInit(): void {
  }

  funSubmit() {
    this.dataArray = this.LocalstorageServiceRef.funGetData();
    this.dataArray = this.dataArray != null ? this.dataArray : [];
    if (this.fname.trim() && this.lname.trim() && this.profession.trim() && this.city.trim() && this.state.trim() && this.zipcode.trim() && this.phone.trim() && this.email.trim()) {
      if (this.currentRefNo != undefined && this.currentRefNo.length > 0) {
        
        let indexData = this.dataArray.filter(data => data.refNo == this.currentRefNo);
        if (indexData.length > 0) {
          let lData = indexData[0];
          lData.fname = this.fname;
          lData.lname = this.lname;
          lData.profession = this.profession;
          lData.city = this.city;
          lData.state = this.state;
          lData.zipcode = this.zipcode;
          lData.phone = this.phone;
          lData.email = this.email;
          let rDataIndx = this.dataArray.map(e => e.refNo).indexOf(this.currentRefNo);
          this.dataArray[rDataIndx] = lData;
        }
      } else {
        let unRefNo = this.LocalstorageServiceRef.randomString(16, 'aA');
        let data = { "refNo": unRefNo, "fname": this.fname, "lname": this.lname, "profession": this.profession, "city": this.city, "state": this.state, "zipcode": this.zipcode, "phone": this.phone, "email": this.email };
        this.dataArray.push(data);
      }
      this.retrievedObject = this.LocalstorageServiceRef.funSetData(this.dataArray);
      if (this.retrievedObject == 1) {
        this.datasaved++;
        this.formReset();
      }
    }
  }
  

  formReset() {
    this.buttonLbl = 'Submit';
    this.currentRefNo = '';
    this.fname = '';
    this.lname = '';
    this.profession = '';
    this.city = '';
    this.state = '';
    this.zipcode = '';
    this.phone = '';
    this.email = '';
  }

  recvEmitData(refNo) {
    this.currentRefNo = refNo;
    this.dataArray = this.LocalstorageServiceRef.funGetData();
    if (this.currentRefNo != undefined) {
      this.buttonLbl = 'Update';
      let indexData = this.dataArray.filter(data => data.refNo == this.currentRefNo);
      if (indexData.length > 0) {
        let lData = indexData[0];
        this.fname = lData.fname;
        this.lname = lData.lname;
        this.profession = lData.profession;
        this.city = lData.city;
        this.state = lData.state;
        this.zipcode = lData.zipcode;
        this.phone = lData.phone;
        this.email = lData.email;
      }
    }
  }

}

