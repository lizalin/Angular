import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentresumeComponent } from './parentresume.component';

describe('ParentresumeComponent', () => {
  let component: ParentresumeComponent;
  let fixture: ComponentFixture<ParentresumeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParentresumeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentresumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
