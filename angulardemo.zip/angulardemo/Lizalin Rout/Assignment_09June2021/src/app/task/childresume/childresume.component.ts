import { Component, Input, OnInit, OnChanges, Output, EventEmitter } from '@angular/core';
import { LocalstorageService } from '../localstorage.service';

@Component({
  selector: 'app-childresume',
  templateUrl: './childresume.component.html',
  styleUrls: ['./childresume.component.scss']
})
export class ChildresumeComponent implements OnInit, OnChanges {
  @Input() parenttochild:any;
  @Output() childtoparent = new EventEmitter();
  retrievedObject:any;
  constructor(private LocalstorageServiceRef:LocalstorageService) { }

  ngOnInit(): void {
  }

  ngOnChanges(){
    if(this.parenttochild != undefined && this.parenttochild >= 0){
      this.loadData();
    }
    
  }

  sendRefNo(refNo){
    this.childtoparent.emit(refNo);
  }
  loadData(){
    this.retrievedObject = this.LocalstorageServiceRef.funGetData();
    this.retrievedObject = this.retrievedObject!=null?this.retrievedObject:[];
  }
  
  deleteRecord(refNo){
    let REAfterData = this.retrievedObject.filter(data=>data.refNo!=refNo);
    this.LocalstorageServiceRef.funSetData(REAfterData);
    this.loadData();
  }

}
