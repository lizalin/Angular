import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildresumeComponent } from './childresume.component';

describe('ChildresumeComponent', () => {
  let component: ChildresumeComponent;
  let fixture: ComponentFixture<ChildresumeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildresumeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildresumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
