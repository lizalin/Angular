import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.scss']
})
export class Child1Component implements OnInit {
  name:string;
  address:string;
  amount:number;
  data:any;

  @Output() eveEmitter = new EventEmitter();
  
  constructor() { 
    
  }

  ngOnInit(): void {
  }

  funSubmit(){
    this.data = {"name":this.name,"address":this.address,"amount":Number(this.amount)};
    this.eveEmitter.emit(this.data);
  }

}
