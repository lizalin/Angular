import { Component, Input, OnInit, OnChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit,OnChanges {
  
  @Input() parenttochild:any;
  name:any;
  address:any;
  constructor() {}

  ngOnInit(): void {
  }

  ngOnChanges(){
    console.log(this.parenttochild);
    if(this.parenttochild!=undefined && this.parenttochild.hasOwnProperty('name')){
      this.name = this.parenttochild.name;
    }
    if(this.parenttochild!=undefined && this.parenttochild.hasOwnProperty('address')){
      this.address = this.parenttochild.address;
    }
  }

}
