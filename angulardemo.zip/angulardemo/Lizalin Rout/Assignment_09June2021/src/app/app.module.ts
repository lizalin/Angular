import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { DemoComponent } from './test/demo/demo.component';
import { ChangeTextDirective } from './change-text.directive';
import { DirectiveComponent } from './directive/directive.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { Parent1Component } from './parent1/parent1.component';
import { Child1Component } from './child1/child1.component';
import { SharedService } from './shared.service';
import { ParentresumeComponent } from './task/parentresume/parentresume.component';
import { ChildresumeComponent } from './task/childresume/childresume.component';
import { LocalstorageService } from './task/localstorage.service';
import { Messenger1Component } from './messenger1/messenger1.component';
import { Messenger2Component } from './messenger2/messenger2.component';
import { MessengerService } from './messenger.service';
import { CustompipePipe } from './custompipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    DemoComponent,
    ChangeTextDirective,
    DirectiveComponent,
    AssignmentComponent,
    ParentComponent,
    ChildComponent,
    Parent1Component,
    Child1Component,
    ParentresumeComponent,
    ChildresumeComponent,
    Messenger1Component,
    Messenger2Component,
    CustompipePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [SharedService,LocalstorageService,MessengerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
