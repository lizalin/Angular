import { Injectable } from '@angular/core';
import { $ } from 'protractor';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  constructor() { }

  addCal(val1,val2){
    return val1+val2;
  }

  moneyFormat(amount){
    console.log(typeof(amount));
    return '$ '+amount.toFixed(2);
  }

}
