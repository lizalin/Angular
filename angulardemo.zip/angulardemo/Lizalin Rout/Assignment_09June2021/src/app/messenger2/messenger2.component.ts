import { Component, OnInit } from '@angular/core';
import { MessengerService } from '../messenger.service';

@Component({
  selector: 'app-messenger2',
  templateUrl: './messenger2.component.html',
  styleUrls: ['./messenger2.component.scss']
})
export class Messenger2Component implements OnInit {
  msgRes:any = [];
  message:any;
  allMsg:any = [];
  constructor(public msgServiceRef:MessengerService) { }

  ngOnInit(): void {
    this.msgServiceRef.getmessage.subscribe((res) => {
      this.msgRes = res;
    })
  }

  sendData(){
    if(this.message.trim()){
      this.allMsg.push({"messages":this.message});
    }
    this.msgServiceRef.setmessage1(this.allMsg);
  }

}
