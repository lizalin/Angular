import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MessengerService {

  constructor() { }
  subjectval = new BehaviorSubject([{"messages":"Hiiii"}]);
  getmessage = this.subjectval.asObservable();

  setmessage(msg){
    this.subjectval.next(msg);
  }

  subjectval1 = new BehaviorSubject([{"messages":"Hiiii"}]);
  getmessage1 = this.subjectval1.asObservable();

  setmessage1(msg){
    this.subjectval1.next(msg);
  }
}
