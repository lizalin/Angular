import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive',
  templateUrl: './directive.component.html',
  styleUrls: ['./directive.component.scss']
})
export class DirectiveComponent implements OnInit {

  employeeDtls:any = [
    {name:"Rojalin",salary:"1000"},
    {name:"Lizalin",salary:"2000"},
    {name:"Pujalin",salary:"3000"},
    {name:"Swagatika",salary:"4000"},
    {name:"Ananya",salary:"5000"},
    {name:"Bhagyashree",salary:"6000"},
    {name:"Prangya",salary:"7000"},
    {name:"Subhashree",salary:"8000"},
    {name:"Chinmayee",salary:"9000"},
    {name:"Sangita",salary:"10000"}
  ];

  isScaled:boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

}
