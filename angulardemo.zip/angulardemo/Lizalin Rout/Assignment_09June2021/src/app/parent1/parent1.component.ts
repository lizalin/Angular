import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-parent1',
  templateUrl: './parent1.component.html',
  styleUrls: ['./parent1.component.scss']
})
export class Parent1Component implements OnInit {
  name:string;
  address:string;
  amount:string;
  res:number;
  constructor(private SharedServiceRef:SharedService) { }

  ngOnInit(): void {
  }

  funEmit(data){
    console.log(data);
    this.name = data.name;
    this.address = data.address;
    this.amount = this.SharedServiceRef.moneyFormat(data.amount);
    this.res = this.SharedServiceRef.addCal(10,20);
  }

}
