import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms'

@Component({
  selector: 'app-formexample',
  templateUrl: './formexample.component.html',
  styleUrls: ['./formexample.component.css']
})
export class FormexampleComponent implements OnInit {
  // name = new FormControl();
  resume = new FormGroup({
    personalDetails : new FormGroup({
      name: new FormControl(''),
      phone: new FormControl(''),
      address: new FormControl(''),
      email: new FormControl(''),
      sociallinks: new FormControl('')
    }),
    skills : new FormControl(''),
    othdtls : new FormControl('')
  });
  // personalDetails = new FormGroup({
  //   name: new FormControl(''),
  //   phone: new FormControl(''),
  //   address: new FormControl(''),
  //   email: new FormControl(''),
  //   sociallinks: new FormControl('')
  // })
  constructor() { }

  ngOnInit(): void {
  }

  // updateName(){
  //   this.name.setValue('Liza');
  //   console.log(this.name.value);

  // }

  onSubmit(){
    console.log(this.resume.value);
  }

  updateResume(){
    this.resume.patchValue({
      personalDetails: {
        name: "Lizalin Rout",
        phone: "9114770026",
        address: "BBSR",
        email: "er.liza2010@gmail.com",
        sociallinks: "gmail"
      },
      skills: "Angular",
      othdtls: "Testing"
    });
  }

}
