import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css']
})
export class ActionComponent implements OnInit {
  recvData:number;
  @Output() parenttochild = new EventEmitter;
  constructor() { }

  ngOnInit(): void {
  }

  funOpenPdf(){
    this.recvData = 1;
    this.parenttochild.emit(this.recvData);
  }

}
