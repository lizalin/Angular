import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormbuilderexmComponent } from './formbuilderexm.component';

describe('FormbuilderexmComponent', () => {
  let component: FormbuilderexmComponent;
  let fixture: ComponentFixture<FormbuilderexmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormbuilderexmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormbuilderexmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
