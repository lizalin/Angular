import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormArray } from '@angular/forms'

@Component({
  selector: 'app-formbuilderexm',
  templateUrl: './formbuilderexm.component.html',
  styleUrls: ['./formbuilderexm.component.css']
})
export class FormbuilderexmComponent implements OnInit {

  constructor(private fb : FormBuilder) { }

  resume = this.fb.group({
    personalDetails : this.fb.group({
      name: ['',Validators.required],
      phone: ['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
      address: [''],
      email: ['',[Validators.email,Validators.required]],
      sociallinks: ['']
    }),
    skills : this.fb.array([
      this.fb.control('')
    ]),
    othdtls : ['']
  })

  ngOnInit(): void {
  }

  onSubmit(){
    console.log(this.resume.value);
  }

  updateResume(){
    this.resume.patchValue({ 
      personalDetails: {
        name: "Lizalin Rout",
        phone: "9114770026",
        address: "BBSR",
        email: "er.liza2010@gmail.com",
        sociallinks: "gmail"
      },
      skills: "Angular",
      othdtls: "Testing"
    });
  }

  get skills() {
    return this.resume.get('skills') as FormArray;
  }

}
