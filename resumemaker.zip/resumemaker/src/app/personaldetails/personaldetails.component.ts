import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personaldetails',
  templateUrl: './personaldetails.component.html',
  styleUrls: ['./personaldetails.component.css']
})
export class PersonaldetailsComponent implements OnInit {
  name:any;
  phone:any;
  address:any;
  email:any;
  sociallinks:any;
  skills:any;
  employer:any;
  jobtitle:any;
  jobdes:any;
  expinmonths:any;
  standard:any;
  school:any;
  yearofpass:any;
  percentage:any;
  othdtls:any;
  data:any;
  constructor() { }

  ngOnInit(): void {
  }

  recvEmitData(evData){
    console.log(evData);
    if(evData == 1){
      this.data = 
      {
        "personal_details":
        {
          "name": this.name,
          "phone":this.phone,
          "address":this.address,
          "email":this.email,
          "sociallinks":this.sociallinks
        },
        "skills":
        [
          this.skills
        ],
        "experience":
        [
          {
           "employer": this.employer,
           "jobtitle": this.jobtitle,
           "jobdes": this.jobdes,
           "expinmonths": this.expinmonths 
          }
        ],
        "education":
        [
          {
           "standard": this.standard,
           "school": this.school,
           "yearofpass": this.yearofpass,
           "percentage": this.percentage 
          }
        ],
        "othdtls":this.othdtls
      }
    }
    console.log(this.data);

  }
}
