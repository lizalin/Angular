import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { PersonaldetailsComponent } from './personaldetails/personaldetails.component';
import { ActionComponent } from './action/action.component';
import { FormexampleComponent } from './formexample/formexample.component';
import { FormbuilderexmComponent } from './formbuilderexm/formbuilderexm.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    PersonaldetailsComponent,
    ActionComponent,
    FormexampleComponent,
    FormbuilderexmComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
